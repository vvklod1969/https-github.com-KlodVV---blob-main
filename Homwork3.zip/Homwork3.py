completed_tasks = 12
hours_spent = 1.5
cours_name = "Pyton"
average_time = hours_spent/completed_tasks
print("Название курса:", cours_name," Количество выполненных домашних заданий =",completed_tasks)
print("Затрачено часов на выполнение =", hours_spent, "Среднее время выполнения одного задания = ", average_time, "часа")
